matemagico
==========

Pequeño juego de matemáticas en JS.

[![Matemagico Javierbyte](docs/matemagico.png)](http://javier.xyz/matemagico/)

Juega Online
http://javier.xyz/matemagico/