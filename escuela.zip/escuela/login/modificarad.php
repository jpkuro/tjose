<?php
require 'dbConnection.php';
$id =$_GET['admin_id'];
$sql= "select admin_id ,  name, email, estado, cedula, celular from admin where $id=admin_id";
$resultado = $con->query($sql);
$row = $resultado->fetch_array();

?>

<!DOCTYPE html>
<html>
<head>
	<title>MODIFICAR DATOS ADMINISTRATIVOS</title>
</head>
<body>
	 <fieldset style="background-color: #87CEEB; font-family: Roboto, sans-serif;";>
<center><h1>MODIFICAR DATOS ADMINISTRATIVOS</h1></center>
 </fieldset>
  <center>
  <form method="post" action="editar2.php">
  <fieldset style="background-color: #DCDCDC">

  	<input type="hidden" name="id" value="<?php echo $row['admin_id']; ?>">
  <b>MODIFICAR CEDULA</b>
  <br>
    <input type="text" name="cedula" placeholder="Ingrese la cedula"  value="<?php echo $row['cedula']; ?>" style="color: #a2a2a2; font-weight: bold; padding: 10px;width:500px; border: 2px solid #d8d8d8; border-radius: 6px;"required>
    <br>
    <br>
  <b>MODIFIQUE NOMBRE</b>
  
  <br>
    <input type="text" name="name" placeholder="Ingrese el nombre" value="<?php echo $row['name']; ?>" style="color: #a2a2a2; font-weight: bold; padding: 10px;width:500px; border: 2px solid #d8d8d8; border-radius: 6px;" required>
    <br>
    
    <br>
    <b> MODIFIQUE EL CORREO ELECTRONICO</b>
  
  <br>
    <input type="email" name="email" placeholder="Ingrese el correo electronico" value="<?php echo $row['email']; ?>" style="color: #a2a2a2; font-weight: bold; padding: 10px; width:500px; border: 2px solid #d8d8d8; border-radius: 6px;" required >
    <br>
    <br>
     <b>MODIFIQUE EL TELEFONO</b>
  
  <br>
    <input type="text" name="mob" placeholder="Ingrese el TELEFONO" value="<?php echo $row['celular']; ?>" style="color: #a2a2a2; font-weight: bold; padding: 10px; width:500px; border: 2px solid #d8d8d8; border-radius: 6px;"required>
    <br>
  <br>
    <input type="hidden" name="password" placeholder="Ingrese la contraseña"style="color: #a2a2a2; font-weight: bold; padding: 10px; width:500px; border: 2px solid #d8d8d8; border-radius: 6px;" required>
   
  <b>MODIFIQUE EL ESTADO</b>
  
  <br>
    <select name="estado"  style="color: #a2a2a2; font-weight: bold; padding: 10px; width:500px; border: 2px solid #d8d8d8; border-radius: 6px;"required>
                <option value="1" <?php if($row['estado']== 1) echo 'selected'; ?>>activo</option>
                <option value="0" <?php if($row['estado']== 0) echo 'selected'; ?>>inactivo</option>

    </select>
    <br>
    <br>
    
    
   <input type="submit" style="
  box-shadow: 3px 4px 0px 0px #54a3f7;
  background:linear-gradient(to bottom, #007dc1 5%, #0061a7 100%);
  background-color:#007dc1;
  border-radius:12px;
  border:1px solid #124d77;
  display:inline-block;
  cursor:pointer;
  color:#ffffff;
  font-family:Impact;
  font-size:25px;
  font-weight:bold;
  padding:7px 25px;
  text-decoration:none;
  text-shadow:0px 1px 0px #154682;
}
.myButton:hover {
  background:linear-gradient(to bottom, #0061a7 5%, #007dc1 100%);
  background-color:#0061a7;
}
.myButton:active {
  position:relative;
  top:1px;
}
" value="registrar" > 
<br>


</fieldset>
  </form></center>



</body>
</html>