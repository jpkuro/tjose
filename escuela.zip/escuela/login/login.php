<?php
session_start();
if(isset($_SESSION["name"])){
session_destroy();
}
?>
<?php
include_once 'dbConnection.php';
$ref=@$_GET['q'];
$name = $_POST['name'];
$apellido = $_POST['apellido'];
$password = $_POST['password'];
$rol = $_POST['rol'];

//$name = stripslashes($name);
//$password = stripslashes($password); 
//$password = addslashes($password);
//$password=($password);

$sql2=mysqli_query($con,"SELECT * FROM user WHERE name='$name' and gender='$apellido' and estado='1' and rol='estudiante'");
	if($f2=mysqli_fetch_assoc($sql2)){
		if($password==$f2['password'] and $rol=="estudiante"){
			$_SESSION['id']=$f2['id'];
			$_SESSION['name']=$f2['name'];
			$_SESSION['gender']=$f2['gender'];
			$_SESSION['rol']=$f2['rol'];
			$_SESSION['email']=$f2['email'];
			$_SESSION['id_curso']=$f2['id_curso'];
			$_SESSION['estado']=$f2['estado'];

			echo '<script>alert("BIENVENIDO ESTUDIANTE")</script> ';
			echo "<script>location.href='account.php?q=1'</script>";
		
		}if ($rol!=$f2['rol']) {
			session_destroy();
			echo '<script>alert("No Esta Autorizado")</script> ';
			echo "<script>location.href='index.php'</script>";
			
		}elseif ($password!=$f2['password']) {
			session_destroy();
			echo '<script>alert("No Esta Autorizado")</script> ';
			echo "<script>location.href='index.php'</script>";
			
		}
	}
	



$sql3=mysqli_query($con,"SELECT * FROM maestro WHERE nombre='$name' and apellido='$apellido' and estado='1' and rol='maestro'");
	if($f3=mysqli_fetch_assoc($sql3)){
		if($password==$f3['password'] and $rol=="maestro"){
			$_SESSION['id']=$f3['id'];
			$_SESSION['nombre']=$f3['nombre'];
			$_SESSION['apellido']=$f3['apellido'];
			$_SESSION['curso']=$f3['curso'];
			$_SESSION['rol']=$f3['rol'];
			$_SESSION['email']=$f3['email'];
			$_SESSION["key"] ='sunny7785068889';

			echo '<script>alert("BIENVENIDO MAESTRO")</script> ';
			echo "<script>location.href='maestro.php?q=1'</script>";
		
		}if ($rol!=$f3['rol']) {
			session_destroy();
			echo '<script>alert("No Esta Autorizado")</script> ';
			echo "<script>location.href='index.php'</script>";
		}elseif ($password!=$f3['password']) {
			session_destroy();
			echo '<script>alert("No Esta Autorizado")</script> ';
			echo "<script>location.href='index.php'</script>";
			
		}
	}
	
?>