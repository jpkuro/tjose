# JuegoPhaser
Un juego para identificar errores ortográficos y es parte de un proyecto final de un curso de Phaserjs.
