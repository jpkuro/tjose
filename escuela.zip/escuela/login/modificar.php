<?php
require 'dbConnection.php';
$id =$_GET['id'];
$sql= "select user.id, user.cedula, user.name, user.gender,user.email, user.mob,rol,estado, curso.id_curso,curso.curso,semestre.id_semestre,semestre.semestre, parcial.id_parcial,parcial.parcial from user inner join curso inner join semestre inner join parcial on user.id_curso=curso.id_curso and user.id_semestre=semestre.id_semestre and user.id_parcial=parcial.id_parcial where $id=user.id";
$resultado = $con->query($sql);
$row = $resultado->fetch_array();

?>
<?php  $semestre ="select id_curso, curso from curso";
$resultado2 =$con->query($semestre);  
?>

<?php  $semestre2 ="select id_semestre, semestre from semestre";
$resultado3 =$con->query($semestre2);  
?>
<!DOCTYPE html>
<html>
<head>
	<title>MODIFICAR DATOS DEL ESTUDIANTE</title>
</head>
<body>
	 <fieldset style="background-color: #87CEEB; font-family: Roboto, sans-serif;";>
<center><h1>MODIFICAR DATOS DEL ESTUDIANTE</h1></center>
 </fieldset>
  <center>
  <form method="post" action="editar.php">
  <fieldset style="background-color: #DCDCDC">

  	<input type="hidden" name="id" value="<?php echo $row['id']; ?>">
  <b>MODIFICAR CEDULA</b>
  <br>
    <input type="text" name="cedula" placeholder="Ingrese la cedula"  value="<?php echo $row['cedula']; ?>" style="color: #a2a2a2; font-weight: bold; padding: 10px;width:500px; border: 2px solid #d8d8d8; border-radius: 6px;"required>
    <br>
    <br>
  <b>MODIFIQUE NOMBRE</b>
  
  <br>
    <input type="text" name="namea" placeholder="Ingrese el nombre" value="<?php echo $row['name']; ?>" style="color: #a2a2a2; font-weight: bold; padding: 10px;width:500px; border: 2px solid #d8d8d8; border-radius: 6px;" required>
    <br>
    <br>
    <b> MODIFIQUE APELLIDO</b>
  
  <br>
    <input type="text" name="apellido" placeholder="Ingrese el apellido" value="<?php echo $row['gender']; ?>"style="color: #a2a2a2; font-weight: bold; padding: 10px; width:500px; border: 2px solid #d8d8d8; border-radius: 6px;" required>
    <br>
    
    <br>
    <b> MODIFIQUE EL CORREO ELECTRONICO</b>
  
  <br>
    <input type="email" name="email" placeholder="Ingrese el correo electronico" value="<?php echo $row['email']; ?>" style="color: #a2a2a2; font-weight: bold; padding: 10px; width:500px; border: 2px solid #d8d8d8; border-radius: 6px;" required >
    <br>
    <br>
     <b>MODIFIQUE EL TELEFONO</b>
  
  <br>
    <input type="text" name="mob" placeholder="Ingrese el TELEFONO" value="<?php echo $row['mob']; ?>" style="color: #a2a2a2; font-weight: bold; padding: 10px; width:500px; border: 2px solid #d8d8d8; border-radius: 6px;"required>
    <br>
  <br>
    <input type="hidden" name="password" placeholder="Ingrese la contraseña"style="color: #a2a2a2; font-weight: bold; padding: 10px; width:500px; border: 2px solid #d8d8d8; border-radius: 6px;" required>
   
   <b> SELECCIONE ROL </b>
  <br>
    <select name="rol"  style="color: #a2a2a2; font-weight: bold; padding: 10px; width:500px; border: 2px solid #d8d8d8; border-radius: 6px;"required>
                <option value="maestro" <?php if($row['rol']== 'maestro') echo 'selected'; ?>>Maestro</option>;
                <option value="estudiante" <?php if($row['rol']== 'estudiante') echo 'selected'; ?>>Estudiante</option>;

    </select>

  <br>
  <b>MODIFIQUE EL ESTADO</b>
  
  <br>
    <select name="estado"  style="color: #a2a2a2; font-weight: bold; padding: 10px; width:500px; border: 2px solid #d8d8d8; border-radius: 6px;"required>
                <option value="1" <?php if($row['estado']== 1) echo 'selected'; ?>>activo</option>
                <option value="0" <?php if($row['estado']== 0) echo 'selected'; ?>>inactivo</option>

    </select>

  <br>

  <div>
    <b> SEMESTRE</b>
  <br>
         <select name="semestre"  style="color: #a2a2a2; font-weight: bold; padding: 10px; width:500px; border: 2px solid #d8d8d8; border-radius: 6px;"required>
                <option value="s001" <?php if($row['id_semestre']== "s001") echo 'selected'; ?>>primer_semestre</option>
                <option value="s002" <?php if($row['id_semestre']== "s002") echo 'selected'; ?>>segundo_semestre</option>

    </select>

    <br>
</div>

<div>
    <b> PARCIAL</b>
  <br>
         <select name="parcial"  style="color: #a2a2a2; font-weight: bold; padding: 10px; width:500px; border: 2px solid #d8d8d8; border-radius: 6px;"required>
                <option value="p001" <?php if($row['id_parcial']== "p001") echo 'selected'; ?>>primer_parcial</option>
                <option value="p002" <?php if($row['id_parcial']== "p002") echo 'selected'; ?>>segundo_parcial</option>

    </select>

    <br>
</div>
<section><div>
  <b> CURSO</b>
  <br>
     <select name="curso" style="color: #a2a2a2; font-weight: bold; padding: 10px; width:500px; border: 2px solid #d8d8d8; border-radius: 6px;"required>
    <option value="<?php echo $row['id_curso']; ?>" selected="selected"> <?php echo $row['curso']; ?> (curso actual)</option>;
                <?php WHILE ($row = $resultado2->fetch_assoc()){?>
                <option value="<?php echo $row["id_curso"];?> "> <?php echo $row["curso"];?> </option>;
                <?php }; ?>

    </select>
    <br></div></section>


    
    
   <input type="submit" style="
  box-shadow: 3px 4px 0px 0px #54a3f7;
  background:linear-gradient(to bottom, #007dc1 5%, #0061a7 100%);
  background-color:#007dc1;
  border-radius:12px;
  border:1px solid #124d77;
  display:inline-block;
  cursor:pointer;
  color:#ffffff;
  font-family:Impact;
  font-size:25px;
  font-weight:bold;
  padding:7px 25px;
  text-decoration:none;
  text-shadow:0px 1px 0px #154682;
}
.myButton:hover {
  background:linear-gradient(to bottom, #0061a7 5%, #007dc1 100%);
  background-color:#0061a7;
}
.myButton:active {
  position:relative;
  top:1px;
}
" value="registrar" > 
<br>


</fieldset>
  </form></center>



</body>
</html>