# Frutakids
La aplicación web Frutakids es un juego simple de clasificación de frutas, cuyo objetivo es ordenar las frutas de menor a mayor precio comercial.
El alumno deberá hacer click en cada fruta presentada por el juego para obtener los datos de ésta. Luego deberá arrastrar cada fruta hacia los cajones de la parte inferior de la pantalla. Por último, el alumno deberá hacer click en el botón revisar para obtener retroalimentación respecto de su desempeño.
